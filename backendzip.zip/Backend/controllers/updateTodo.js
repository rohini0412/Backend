const Todo  = require("../models/Todo") ;

exports.updateTodo= async(req ,res)=>{
    try{
         const id = req.params.id ;
         const{title, description} = req.body ;
        const todos = await Todo.findByIdAndUpdate({_id:id},{title ,description,updateAt:Date.now()},)

        
        res.status(200).json({
            success:true ,
            data:todos ,
            message:`updated successfully` 
          });
    }

    catch(err){
     console.log(err) ;
     console.error(err) ;
     res.status(500).json(
        {success: false ,
        data: "internal server error" ,
        message:err.message})
    }
}