const Todo  = require("../models/Todo") ;

exports.getTodoById= async(req ,res)=>{
    try{
         const id = req.params.id ;
        const todos = await Todo.findById({_id:id})

        if(!todos){
            return res.status(404).json({
                success:false ,
                message:"no data found with given id" ,
            })
        }

        res.status(200).json({
            success:true ,
            data:todos ,
            message:`${id} is fetched successfully` 
          });
    }

    catch(err){
     console.log(err) ;
     console.error(err) ;
     res.status(500).json(
        {success: false ,
        data: "internal server error" ,
        message:err.message})
    }
}